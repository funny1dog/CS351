**MAZE Project**

Chen - Kruskal/Random Mouse
Usage:
Create a config.txt file

Save the config.txt file under c:\Project4\config.txt

Example: config.txt
900
30
kruskal
mouse