package Jia.src.Cell;

import Jia.src.Algorithm.MazeGenerationAlgorithm.MazeGenerationAlgorithm;
import Jia.src.Algorithm.MazeSolverAlgorithm.SolvingAlgorithm;
import Jia.src.View.Painter;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

/**
 *
 * @author
 */
public class Grid extends Observable implements Observer
{    
    // Dimensions
    private int x_size;
    private int y_size;
    
    // Grid
    private Tile[][] grid;
    Tile start, end;
    
    // What change will happen to the tile on click
    private Tile.Type clickType;
    
    // Attributes
    private final Painter painter;
    
    public Grid()
    {
        this.start = null;
        this.end = null;
        this.clickType = Tile.Type.START;
        painter = Painter.getInstance();
    }
    
    /**
     * Runs an algorithm specified as 'solvingAlgorithm' to solve maze from start to end
     * @return boolean
     */
    public boolean executePathfinding(SolvingAlgorithm solvingAlgorithm) throws InterruptedException
    {
        if(start == null || end == null) return false;
        this.painter.clearPath(this);
        
        List<Tile> path = new ArrayList<>();
        
        solvingAlgorithm.algorithm(this, path);
        
        return true;
    }
    
    /**
     * Initializes the grid with all it's tiles in an empty state.
     * This method is only meant to be called once before runtime.
     */
    public void gridInit(int x_tiles, int y_tiles, int tile_size)
    {
        this.x_size = x_tiles;
        this.y_size = y_tiles;
        this.grid = new Tile[x_tiles][y_tiles];
        
        // Initializes all tiles
        for(int y = 0; y < y_tiles; y++)
        {
            for(int x = 0; x < x_tiles; x++)
            {
                Tile tile = new Tile(x, y, tile_size); 
                tile.addObserver(this);
                grid[x][y] = tile;
            }
        }
    }
    
    /**
     * Toggles all tiles to show respective coordinates
     * @param toAdd toAdd true if it's to add coords, false if it's to remove
     */
    public void toggleCoords(boolean toAdd)
    {
        for(int y = 0; y < this.y_size; y++)
        {
            for(int x = 0; x < this.x_size; x++)
            {
                grid[x][y].toggleCoords(toAdd);
            }
        }
    }
    
    /**
     * Returns the Tile 2Dimensional vector, representing the grid
     * @return Tile[][] grid
     */
    public Tile[][] getGrid()
    {
        return this.grid;
    }
    
    /**
     * Checks if the grid is ready to run. (E.g. If a root and target node were selected)
     * @return true if grid is ready to run an algorithm, false if root and target are not set
     */
    public boolean isReady()
    {
        return !(start == null || end == null);
    }
    
    /**
     * Returns a list with all the tiles in this grid
     * @return all tiles
     */
    public List<Tile> getTiles()
    {
        List<Tile> tiles = new ArrayList<>();
        
        for(int y = 0; y < this.y_size; y++)
        {
            for(int x = 0; x < this.x_size; x++)
            {
                tiles.add(grid[x][y]);
            }
        }
        
        return tiles;
    }
    
    /**
     * Sets all Tiles in the grid to default (Empty, defaultWeight)!
     */
    public void clearGrid()
    {
        for(int y = 0; y < this.y_size; y++)
        {
            for(int x = 0; x < this.x_size; x++)
            {
                grid[x][y].clearTile();
            }
        }
    }
    
    /**
     * Sets the border for all tiles
     * @param setBorder true to set border, false to remove border
     */
    public void addTileBorders(boolean setBorder)
    {
        for(int y = 0; y < this.y_size; y++)
        {
            for(int x = 0; x < this.x_size; x++)
            {
                grid[x][y].setTileStroke(setBorder);
            }
        }
    }
    
    /**
     * Returns total amount of walls in the grid
     */
    public int getWallsAmount()
    {
        int totalWalls = 0;
        
        for(int y = 0; y < this.y_size; y++)
        {
            for(int x = 0; x < this.x_size; x++)
            {
                if(grid[x][y].isWall()) totalWalls++;
            }
        }
        
        return totalWalls;
    }
    
    /**
     * Return neighbors of 'tile'
     */
    public List<Tile> getTileNeighbors(Tile tile)
    {
        List<Tile> neighbors = new ArrayList<>();
        
        neighbors.add(this.getNorthTile(tile));
        neighbors.add(this.getSouthTile(tile));
        neighbors.add(this.getEastTile(tile));
        neighbors.add(this.getWestTile(tile));
        
        return neighbors;
    }
    
    /**
     * Returns tile to the north of 'tile'
     * @param tile north tile
     * @return Tile
     */
    public Tile getNorthTile(Tile tile)
    {
        return (tile.getY() - 1 >= 0) ? grid[tile.getX()][tile.getY() - 1] : null;
    }
    
    /**
     * Returns tile to the south of 'tile'
     * @param tile south tile
     * @return Tile
     */
    public Tile getSouthTile(Tile tile)
    {
        return (tile.getY() + 1 <= y_size - 1) ? grid[tile.getX()][tile.getY() + 1] : null;
    }
    
    /**
     * Returns tile to the west (left) of 'tile'
     * @param tile west tile
     * @return Tile
     */
    public Tile getWestTile(Tile tile)
    {
        return (tile.getX() - 1 >= 0) ? grid[tile.getX() - 1][tile.getY()] : null;
    }
    
    /**
     * Returns tile to the East (right) of 'tile'
     * @param tile east tile
     * @return Tile
     */
    public Tile getEastTile(Tile tile)
    {
        return (tile.getX() + 1  <= x_size - 1) ? grid[tile.getX() + 1][tile.getY()] : null;
    }

    
    /**
     * Returns height of maze
     * @return int
     */
    public int getYSize()
    {
        return this.y_size;
    }
    
    /**
     * Returns width of maze
     * @return int
     */
    public int getXSize()
    {
        return this.x_size;
    }
    
    /**
     * Changes the current click type
     */
    public void changeClickType(Tile.Type type)
    {
        this.clickType = type;
    }
    
    /**
     * Returns start Tile
     * @return Tile
     */
    public Tile getStart()
    {
        return this.start;
    }
    
    /**
     * Returns END tile
     * @return Tile
     */
    public Tile getEnd()
    {
        return this.end;
    }


    
    /**
     * Generates a random maze using a recursive backtracker algorithm
     * @param mazeGenerationAlgorithm maze generation algorithm
     */
    public void generateRandomMaze(MazeGenerationAlgorithm mazeGenerationAlgorithm)
    {
        mazeGenerationAlgorithm.generate(this);
    }
    
    @Override
    public void update(Observable o, Object arg)
    {
        // If the update came from a Tile Object
        if(o instanceof Tile)
        {
            Tile tile = (Tile)o;

            // User can't override a wall, unless he's setting it as empty first.
            if(tile.isWall())
            {
                if(this.clickType == Tile.Type.EMPTY)
                    tile.setAttributes(clickType, tile.getDefaultWeight());
                return;
            }

            // What happens when you click a tile with a specific clickType (I.e. root, target, wall...)
            switch(this.clickType)
            {
                // Tiles that  can only have one ocurrence throughout the grid
                case START: case END:

                    // Clear old tiles
                    if(clickType == Tile.Type.START)
                    {
                        if(this.start != null) start.clearTile();
                        this.start = tile;
                    }
                    else {
                        if(this.end != null) end.clearTile();
                        this.end = tile;
                    }

                    tile.setAttributes(clickType, tile.getDefaultWeight());

                    break;
                // Tiles that allow multiple ocurrences of themselfs
                default:
                    tile.setAttributes(clickType, tile.getWeight());
                    break;
            }
        }

        // If the update came from statistics
        if(o instanceof Counter)
        {
            Counter stats = (Counter)o;
            setChanged();
            notifyObservers(stats);
        }
    }
}
